#!/bin/sh

################################################## 
# 			Remove lixo gerado pelo script		 #
################################################## 
rm -f 2step/*.pdf 2step/*.fst
rm -f 1step/*.pdf 1step/*.fst
rm -f 3step/*.pdf 3step/*.fst
rm -f 4step/*.pdf 4step/*.fst 4step/result-4step.txt
mv transdutorFinal.fst transdutorFinal.fst1
rm -f *.pdf *.fst transdutorFinal.txt
mv transdutorFinal.fst1 transdutorFinal.fst
rm -fr tests-results
rm -f result.txt
