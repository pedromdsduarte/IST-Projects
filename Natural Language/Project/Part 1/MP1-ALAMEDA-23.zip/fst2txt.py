import sys
f = open(sys.argv[1],'r');
array = f.readlines();
f.close()
array.sort(reverse=True)
list1 = []
word = ''

for x in range(0,len(array)-1):
    list1.append(array[x].split('\t'))
list1.sort(key=lambda x:int(x[0]),reverse=True)
for x in range(0,len(list1)):
    if(list1[x][3][0:3] != 'eps' ):
        word += list1[x][3]
        
print "Output word: " + word