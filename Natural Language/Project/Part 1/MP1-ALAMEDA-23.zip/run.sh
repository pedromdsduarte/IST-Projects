#!/bin/sh

WORD=$1
STEP='0'
VERBOSE=true
ALL=false
GENERATE=false
if [ "$#" -eq 0 ]; 
then
	echo "Invalid use: USAGE: ./run.sh -w WORD [-options]"
	echo "Use -h to see more options"
	exit 0
fi

while getopts 'w:hvgs:a:' flag; do
	case "${flag}" in
		w ) 		
			WORD=${OPTARG}	
			;;
		s )
			STEP=${OPTARG}
			if [ $STEP -gt 4 ] || [ $STEP -lt 1 ] ; then
                            echo "Invalid step number, must be between 1 and 4"
                            exit 1
                        fi
			;;
		v )
			VERBOSE=false
			;;
		a )     ALL=true
                        ;;
                g )     GENERATE=true
                        ;;
		h )
			echo "USAGE: ./run.sh -w WORD"
			echo "OPTIONS:"
			echo "-w[=STRING]\tUse the word that you want to convert"
			echo "-v\t\tVerbose: Disable verbose"
			echo "-s[=(1-4)]\tPerform certain step (1 to 4)"
			echo "-a\t\tShow all output steps"
			echo "-g\t\tGenerates the transductor"
			exit 0
			;;
		? )
			echo "Invalid use: USAGE: ./run.sh -w WORD [-options]"
			echo "Use -h to see more options"
			exit 1
			;; 
		* ) 	
			echo "Invalid use: USAGE: ./run.sh -w WORD [-options]"
			echo "Use -h to see more options"
			exit 1
			;;
	esac
done
echo "Input word: "$WORD

if [ $GENERATE = false ]; then
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf

    fstcompose $WORD.fst transdutorFinal.fst | fstshortestpath | fstrmepsilon > result.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt result.fst | dot -Tpdf > result.pdf
    fstprint --isymbols=syms.txt --osymbols=syms.txt result.fst result.txt
    python fst2txt.py result.txt
    rm $WORD.txt $WORD.fst $WORD.pdf
else
if [ $STEP -eq 0 ] ; then
    echo "Executing ALL STEPS..."
    ################################################## 
    # 			GERA A PALAVRA PARA INPUT			 #
    ################################################## 
    if $VERBOSE; then echo "[00%] Generating:\t input fst"; fi
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf



    ################################################## 
    #  1 STEP	# GERA OS 2 TRANSDUTORES		     #
    ################################################## 
    if $VERBOSE; then echo "[10%] Generating:\t step1 fst"; fi
    # X PARA ZS
    python compact2fst.py 1step/xparazs-compacto.txt > 1step/xparazs.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 1step/xparazs.txt | fstarcsort > 1step/xparazs.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/xparazs.fst | dot -Tpdf > 1step/xparazs.pdf

    # S PARA Z
    python compact2fst.py 1step/sparaz-compacto.txt > 1step/sparaz.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 1step/sparaz.txt | fstarcsort > 1step/sparaz.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/sparaz.fst | dot -Tpdf > 1step/sparaz.pdf


    ################################################## 
    #  1 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    fstconcat 1step/xparazs.fst 1step/sparaz.fst > 1step/1step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/1step.fst | dot -Tpdf > 1step/1step.pdf
    fstcompose $WORD.fst 1step/1step.fst | fstshortestpath | fstrmepsilon > 1step/result-1step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/result-1step.fst | dot -Tpdf > 1step/result-1step.pdf


    ################################################## 
    #  2 STEP	# GERA OS 4 TRANSDUTORES		     #
    ################################################## 
    if $VERBOSE; then echo "[20%] Generating:\t step2 fst"; fi
    # CH PARA X  | LH PARA 2
    python compact2fst.py 2step/chlhparax2-compacto.txt > 2step/chlhparax2.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/chlhparax2.txt | fstarcsort > 2step/chlhparax2.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/chlhparax2.fst | dot -Tpdf > 2step/chlhparax2.pdf

    # NH PARA 3
    python compact2fst.py 2step/nhpara3-compacto.txt > 2step/nhpara3.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/nhpara3.txt | fstarcsort > 2step/nhpara3.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/nhpara3.fst | dot -Tpdf > 2step/nhpara3.pdf

    # RR PARA 4 
    python compact2fst.py 2step/rrpara4-compacto.txt > 2step/rrpara4.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/rrpara4.txt | fstarcsort > 2step/rrpara4.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/rrpara4.fst | dot -Tpdf > 2step/rrpara4.pdf

    # SS PARA S
    python compact2fst.py 2step/ssparas-compacto.txt > 2step/ssparas.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/ssparas.txt | fstarcsort > 2step/ssparas.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/ssparas.fst | dot -Tpdf > 2step/ssparas.pdf


    ################################################## 
    #  2 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[30%] Composing:\t result_step1+step2 fst"; fi
    fstcompose 2step/chlhparax2.fst 2step/nhpara3.fst > 2step/chlhnhparax23.fst
    fstcompose 2step/chlhnhparax23.fst 2step/rrpara4.fst > 2step/chlhnhrrparax234.fst
    fstcompose 2step/chlhnhrrparax234.fst 2step/ssparas.fst > 2step/2step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/2step.fst | dot -Tpdf > 2step/2step.pdf
    fstcompose 1step/result-1step.fst 2step/2step.fst | fstshortestpath | fstrmepsilon > 2step/result-2step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/result-2step.fst | dot -Tpdf > 2step/result-2step.pdf


    ################################################## 
    #  3 STEP	# GERA OS 1 TRANSDUTOR  		     #
    ################################################## 
    if $VERBOSE; then echo "[40%] Generating:\t step3 fst"; fi
    python compact2fst.py 3step/terc-compacto.txt > 3step/terc.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 3step/terc.txt | fstarcsort > 3step/3step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 3step/3step.fst | dot -Tpdf > 3step/3step.pdf


    ################################################## 
    #  3 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[50%] Composing:\t result_step2+step3 fst"; fi
    fstcompose 2step/result-2step.fst 3step/3step.fst | fstshortestpath | fstrmepsilon > 3step/result-3step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 3step/result-3step.fst | dot -Tpdf > 3step/result-3step.pdf


    ################################################## 
    #  4 STEP	# GERA OS 1 TRANSDUTOR  		     #
    ################################################## 
    if $VERBOSE; then echo "[60%] Generating:\t step4 fst"; fi
    python compact2fst.py 4step/vogais-compacto.txt > 4step/vogais.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 4step/vogais.txt | fstarcsort > 4step/4step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 4step/4step.fst | dot -Tpdf > 4step/4step.pdf


    ################################################## 
    #  4 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[70%] Composing:\t result_step3+step4 fst"; fi
    fstcompose 3step/result-3step.fst 4step/4step.fst | fstshortestpath | fstrmepsilon > 4step/result-4step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 4step/result-4step.fst | dot -Tpdf > 4step/result-4step.pdf
    #cp 4step/result-4step.pdf transdutorFinal.pdf
    #cp 4step/result-4step.fst transdutorFinal.fst
    #fstprint --isymbols=syms.txt --osymbols=syms.txt 4step/result-4step.fst transdutorFinal.txt

    if $VERBOSE; then echo "[80%] Composing:\t transdutorFinal+input fst"; fi
    fstcompose 1step/1step.fst 2step/2step.fst > temp.fst
    fstcompose temp.fst 3step/3step.fst > temp1.fst 
    fstcompose temp1.fst 4step/4step.fst > transdutorFinal.fst
    fstcompose $WORD.fst transdutorFinal.fst | fstshortestpath | fstrmepsilon > result.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt result.fst | dot -Tpdf > result.pdf
    fstprint --isymbols=syms.txt --osymbols=syms.txt result.fst result.txt
    
    ################################################## 
    #  4 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[90%] Coping results to default folder"; fi
    if $ALL; then
        cp 1step/result-1step.pdf 1result.pdf
        cp 2step/result-2step.pdf 2result.pdf
        cp 3step/result-3step.pdf 3result.pdf
        cp 4step/result-4step.pdf 4result.pdf
    fi
    ################################################## 
    # 				LIMPA OS INPUTS					 #
    ##################################################
    if $VERBOSE; then echo "[95%] Removing trash"; fi
    rm -f $WORD.txt $WORD.fst $WORD.pdf temp.fst temp1.fst
    if $VERBOSE; then echo "[100%] Completed! Check result.pdf"; fi
    python fst2txt.py result.txt
   # cp 4step/result-4step.fst transdutorFinal.fst
   # rm -f result.txt
fi


if [ $STEP -eq 1 ] ; then
    echo "Executing ONLY STEP 1..."
    ################################################## 
    # 			GERA A PALAVRA PARA INPUT			 #
    ################################################## 
    if $VERBOSE; then echo "[00%] Generating:\t input fst"; fi
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf
    
    ################################################## 
    #  1 STEP	# GERA OS 2 TRANSDUTORES		     #
    ################################################## 
    if $VERBOSE; then echo "[25%] Generating:\t step1 fst"; fi
    # X PARA ZS
    python compact2fst.py 1step/xparazs-compacto.txt > 1step/xparazs.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 1step/xparazs.txt | fstarcsort > 1step/xparazs.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/xparazs.fst | dot -Tpdf > 1step/xparazs.pdf

    # S PARA Z
    python compact2fst.py 1step/sparaz-compacto.txt > 1step/sparaz.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 1step/sparaz.txt | fstarcsort > 1step/sparaz.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/sparaz.fst | dot -Tpdf > 1step/sparaz.pdf
    ################################################## 
    #  1 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[50%] Composing:\t input+step1 fst"; fi
    fstconcat 1step/xparazs.fst 1step/sparaz.fst > 1step/1step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/1step.fst | dot -Tpdf > 1step/1step.pdf
    fstcompose $WORD.fst 1step/1step.fst | fstshortestpath | fstrmepsilon > 1step/result-1step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/result-1step.fst | dot -Tpdf > 1step/result-1step.pdf
    fstprint --isymbols=syms.txt --osymbols=syms.txt 1step/result-1step.fst result.txt
    ################################################## 
    #  1 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[75%] Coping results to default folder"; fi
    if $ALL; then
        cp 1step/result-1step.pdf 1result.pdf
    fi
    ################################################## 
    # 				LIMPA OS INPUTS					 #
    ##################################################
    if $VERBOSE; then echo "[90%] Removing trash"; fi
    rm -f $WORD.txt $WORD.fst $WORD.pdf
    if $VERBOSE; then echo "[100%] Completed! Check result.pdf"; fi
    python fst2txt.py result.txt
    rm -f result.txt
fi

if [ $STEP -eq 2 ] ; then
    echo "Executing ONLY STEP 2..."
    ################################################## 
    # 			GERA A PALAVRA PARA INPUT			 #
    ################################################## 
    if $VERBOSE; then echo "[00%] Generating:\t input fst"; fi
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf
    
    if $VERBOSE; then echo "[25%] Generating:\t step2 fst"; fi
    # CH PARA X  | LH PARA 2
    python compact2fst.py 2step/chlhparax2-compacto.txt > 2step/chlhparax2.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/chlhparax2.txt | fstarcsort > 2step/chlhparax2.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/chlhparax2.fst | dot -Tpdf > 2step/chlhparax2.pdf

    # NH PARA 3
    python compact2fst.py 2step/nhpara3-compacto.txt > 2step/nhpara3.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/nhpara3.txt | fstarcsort > 2step/nhpara3.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/nhpara3.fst | dot -Tpdf > 2step/nhpara3.pdf

    # RR PARA 4 
    python compact2fst.py 2step/rrpara4-compacto.txt > 2step/rrpara4.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/rrpara4.txt | fstarcsort > 2step/rrpara4.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/rrpara4.fst | dot -Tpdf > 2step/rrpara4.pdf

    # SS PARA S
    python compact2fst.py 2step/ssparas-compacto.txt > 2step/ssparas.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/ssparas.txt | fstarcsort > 2step/ssparas.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/ssparas.fst | dot -Tpdf > 2step/ssparas.pdf


    ################################################## 
    #  2 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[50%] Composing:\t input+step2 fst"; fi
    fstcompose 2step/chlhparax2.fst 2step/nhpara3.fst > 2step/chlhnhparax23.fst
    fstcompose 2step/chlhnhparax23.fst 2step/rrpara4.fst > 2step/chlhnhrrparax234.fst
    fstcompose 2step/chlhnhrrparax234.fst 2step/ssparas.fst > 2step/2step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/2step.fst | dot -Tpdf > 2step/2step.pdf
    fstcompose $WORD.fst 2step/2step.fst | fstshortestpath | fstrmepsilon > 2step/result-2step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/result-2step.fst | dot -Tpdf > 2step/result-2step.pdf
    fstprint --isymbols=syms.txt --osymbols=syms.txt 2step/result-2step.fst result.txt
    ################################################## 
    #  2 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[75%] Coping results to default folder"; fi
    if $ALL; then
        cp 2step/result-2step.pdf 2result.pdf
    fi
    ################################################## 
    # 				LIMPA OS INPUTS					 #
    ##################################################
    if $VERBOSE; then echo "[90%] Removing trash"; fi
    rm -f $WORD.txt $WORD.fst $WORD.pdf
    if $VERBOSE; then echo "[100%] Completed! Check result.pdf"; fi
    python fst2txt.py result.txt
    rm -f result.txt
fi

if [ $STEP -eq 3 ] ; then
    echo "Executing ONLY STEP 3..."
    ################################################## 
    # 			GERA A PALAVRA PARA INPUT			 #
    ################################################## 
    if $VERBOSE; then echo "[00%] Generating:\t input fst"; fi
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf
    ################################################## 
    #  3 STEP	# GERA OS 1 TRANSDUTOR  		     #
    ################################################## 
    if $VERBOSE; then echo "[25%] Generating:\t step3 fst"; fi
    python compact2fst.py 3step/terc-compacto.txt > 3step/terc.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 3step/terc.txt | fstarcsort > 3step/3step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 3step/3step.fst | dot -Tpdf > 3step/3step.pdf
    ################################################## 
    #  3 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[50%] Composing:\t input+step3 fst"; fi
    fstcompose $WORD.fst 3step/3step.fst | fstshortestpath | fstrmepsilon > 3step/result-3step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 3step/result-3step.fst | dot -Tpdf > 3step/result-3step.pdf
    fstprint --isymbols=syms.txt --osymbols=syms.txt 3step/result-3step.fst result.txt
    ################################################## 
    #  3 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[75%] Coping results to default folder"; fi
    if $ALL; then
        cp 3step/result-3step.pdf 3result.pdf
    fi
    ################################################## 
    # 				LIMPA OS INPUTS					 #
    ##################################################
    if $VERBOSE; then echo "[90%] Removing trash"; fi
    rm -f $WORD.txt $WORD.fst $WORD.pdf
    if $VERBOSE; then echo "[100%] Completed! Check result.pdf"; fi
    python fst2txt.py result.txt
    rm -f result.txt
fi

if [ $STEP -eq 4 ] ; then
    echo "Executing ONLY STEP 4..."
    ################################################## 
    # 			GERA A PALAVRA PARA INPUT			 #
    ################################################## 
    if $VERBOSE; then echo "[00%] Generating:\t input fst"; fi
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf
     ################################################## 
    #  4 STEP	# GERA OS 1 TRANSDUTOR  		     #
    ################################################## 
    if $VERBOSE; then echo "[25%] Generating:\t step4 fst"; fi
    python compact2fst.py 4step/vogais-compacto.txt > 4step/vogais.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 4step/vogais.txt | fstarcsort > 4step/4step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 4step/4step.fst | dot -Tpdf > 4step/4step.pdf
    ################################################## 
    #  4 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[50%] Composing:\t result_step3+step4 fst"; fi
    fstcompose $WORD.fst 4step/4step.fst | fstshortestpath | fstrmepsilon > 4step/result-4step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 4step/result-4step.fst | dot -Tpdf > 4step/result-4step.pdf
    cp 4step/result-4step.pdf result.pdf
    fstprint --isymbols=syms.txt --osymbols=syms.txt 4step/result-4step.fst result.txt
    ################################################## 
    #  4 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[75%] Coping results to default folder"; fi
    if $ALL; then
        cp 4step/result-4step.pdf 4result.pdf
    fi
    ################################################## 
    # 				LIMPA OS INPUTS					 #
    ##################################################
    if $VERBOSE; then echo "[90%] Removing trash"; fi
    rm -f $WORD.txt $WORD.fst $WORD.pdf
    if $VERBOSE; then echo "[100%] Completed! Check result.pdf"; fi
    python fst2txt.py result.txt
    rm -f result.txt
fi
fi