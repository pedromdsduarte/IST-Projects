#!/bin/sh
FIALHO='fialho'
SANTOS='santos'
TAPROBANA='taprobana'
mkdir tests-results
for WORD in $FIALHO $SANTOS $TAPROBANA
do

mkdir tests-results/$WORD
echo "Input word: "$WORD
echo "Executing ALL STEPS..."
    ################################################## 
    # 			GERA A PALAVRA PARA INPUT			 #
    ################################################## 
    if $VERBOSE; then echo "[00%] Generating:\t input fst"; fi
    python word2fst.py $WORD > $WORD.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt $WORD.txt | fstarcsort > $WORD.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt $WORD.fst | dot -Tpdf > $WORD.pdf



    ################################################## 
    #  1 STEP	# GERA OS 2 TRANSDUTORES		     #
    ################################################## 
    if $VERBOSE; then echo "[10%] Generating:\t step1 fst"; fi
    # X PARA ZS
    python compact2fst.py 1step/xparazs-compacto.txt > 1step/xparazs.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 1step/xparazs.txt | fstarcsort > 1step/xparazs.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/xparazs.fst | dot -Tpdf > 1step/xparazs.pdf

    # S PARA Z
    python compact2fst.py 1step/sparaz-compacto.txt > 1step/sparaz.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 1step/sparaz.txt | fstarcsort > 1step/sparaz.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/sparaz.fst | dot -Tpdf > 1step/sparaz.pdf


    ################################################## 
    #  1 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[20%] Composing:\t input+step1 fst"; fi
    fstconcat 1step/xparazs.fst 1step/sparaz.fst > 1step/1step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/1step.fst | dot -Tpdf > 1step/1step.pdf
    fstcompose $WORD.fst 1step/1step.fst | fstshortestpath | fstrmepsilon > 1step/result-1step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 1step/result-1step.fst | dot -Tpdf > 1step/result-1step.pdf


    ################################################## 
    #  2 STEP	# GERA OS 4 TRANSDUTORES		     #
    ################################################## 
    if $VERBOSE; then echo "[30%] Generating:\t step2 fst"; fi
    # CH PARA X  | LH PARA 2
    python compact2fst.py 2step/chlhparax2-compacto.txt > 2step/chlhparax2.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/chlhparax2.txt | fstarcsort > 2step/chlhparax2.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/chlhparax2.fst | dot -Tpdf > 2step/chlhparax2.pdf

    # NH PARA 3
    python compact2fst.py 2step/nhpara3-compacto.txt > 2step/nhpara3.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/nhpara3.txt | fstarcsort > 2step/nhpara3.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/nhpara3.fst | dot -Tpdf > 2step/nhpara3.pdf

    # RR PARA 4 
    python compact2fst.py 2step/rrpara4-compacto.txt > 2step/rrpara4.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/rrpara4.txt | fstarcsort > 2step/rrpara4.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/rrpara4.fst | dot -Tpdf > 2step/rrpara4.pdf

    # SS PARA S
    python compact2fst.py 2step/ssparas-compacto.txt > 2step/ssparas.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 2step/ssparas.txt | fstarcsort > 2step/ssparas.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/ssparas.fst | dot -Tpdf > 2step/ssparas.pdf


    ################################################## 
    #  2 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[40%] Composing:\t result_step1+step2 fst"; fi
    fstcompose 2step/chlhparax2.fst 2step/nhpara3.fst > 2step/chlhnhparax23.fst
    fstcompose 2step/chlhnhparax23.fst 2step/rrpara4.fst > 2step/chlhnhrrparax234.fst
    fstcompose 2step/chlhnhrrparax234.fst 2step/ssparas.fst > 2step/2step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/2step.fst | dot -Tpdf > 2step/2step.pdf
    fstcompose 1step/result-1step.fst 2step/2step.fst | fstshortestpath | fstrmepsilon > 2step/result-2step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 2step/result-2step.fst | dot -Tpdf > 2step/result-2step.pdf


    ################################################## 
    #  3 STEP	# GERA OS 1 TRANSDUTOR  		     #
    ################################################## 
    if $VERBOSE; then echo "[50%] Generating:\t step3 fst"; fi
    python compact2fst.py 3step/terc-compacto.txt > 3step/terc.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 3step/terc.txt | fstarcsort > 3step/3step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 3step/3step.fst | dot -Tpdf > 3step/3step.pdf


    ################################################## 
    #  3 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[60%] Composing:\t result_step2+step3 fst"; fi
    fstcompose 2step/result-2step.fst 3step/3step.fst | fstshortestpath | fstrmepsilon > 3step/result-3step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 3step/result-3step.fst | dot -Tpdf > 3step/result-3step.pdf


    ################################################## 
    #  4 STEP	# GERA OS 1 TRANSDUTOR  		     #
    ################################################## 
    if $VERBOSE; then echo "[70%] Generating:\t step4 fst"; fi
    python compact2fst.py 4step/vogais-compacto.txt > 4step/vogais.txt
    fstcompile --isymbols=syms.txt --osymbols=syms.txt 4step/vogais.txt | fstarcsort > 4step/4step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 4step/4step.fst | dot -Tpdf > 4step/4step.pdf


    ################################################## 
    #  4 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[80%] Composing:\t result_step3+step4 fst"; fi
    fstcompose 3step/result-3step.fst 4step/4step.fst | fstshortestpath | fstrmepsilon > 4step/result-4step.fst
    fstdraw --isymbols=syms.txt --osymbols=syms.txt 4step/result-4step.fst | dot -Tpdf > 4step/result-4step.pdf
    cp 4step/result-4step.fst tests-results/$WORD/result.fst
    fstprint --isymbols=syms.txt --osymbols=syms.txt 4step/result-4step.fst tests-results/$WORD/result.txt

    ################################################## 
    #  4 STEP	# GERA O RESULTADO FINAL			 #
    ################################################## 
    if $VERBOSE; then echo "[90%] Coping results to tests-results/$WORD/"; fi
    if $ALL; then
        cp 1step/result-1step.pdf tests-results/$WORD/1step-result.pdf
        cp 2step/result-2step.pdf tests-results/$WORD/2step-result.pdf
        cp 3step/result-3step.pdf tests-results/$WORD/3step-result.pdf
        cp 4step/result-4step.pdf tests-results/$WORD/4step-result.pdf
        cp 4step/result-4step.pdf tests-results/$WORD/result.pdf
    fi
    ################################################## 
    # 				LIMPA OS INPUTS					 #
    ##################################################
    if $VERBOSE; then echo "[95%] Removing trash"; fi
    rm -f $WORD.txt $WORD.fst $WORD.pdf
    if $VERBOSE; then echo "[100%] Completed! Check tests-results/$WORD/4step-result.pdf"; fi
    python fst2txt.py tests-results/$WORD/result.txt

done
echo ''
echo "All words processed, check tests-results/ folder"
echo ''