#ifndef __ESCRITOR_H__
#define __ESCRITOR_H__

#define NUM_CYCLES 5120

int randomNumber(int max);
int choose_file(char *filename);
int choose_letter();

#endif
