#ifndef __LEITOR_H__
#define __LEITOR_H__

int open_file(char *filename);
int confirma_string(char * buffer, char letters[NUM_STRINGS][NUM_CHARS]);

#endif
