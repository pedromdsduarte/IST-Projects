#ifndef __PARALELO_H__
#define __PARALELO_H__

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>

#include <sys/time.h>

#define NUM_CHILDS 10

#endif
