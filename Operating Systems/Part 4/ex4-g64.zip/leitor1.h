#ifndef __LEITOR1_PAI_H__
#define __LEITOR1_PAI_H__

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdlib.h>
#include <time.h>

#define NUM_CHILDS 3

#endif
